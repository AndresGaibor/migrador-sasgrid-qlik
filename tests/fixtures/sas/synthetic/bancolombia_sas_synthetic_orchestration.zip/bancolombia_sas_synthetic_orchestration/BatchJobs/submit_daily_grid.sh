#!/usr/bin/env bash
# Schedule: Weekdays 06:15 | análisis de SAS Grid; no ejecutar durante carga del ZIP.
set -euo pipefail

sasgsub \
  -gridsubmitpgm "BatchJobs/run_daily_portfolio.sas" \
  -gridjobname "BANKING_PORTFOLIO_TEST" \
  -gridqueue "TEST" \
  -gridwaitresults
